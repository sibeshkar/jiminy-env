AAcom.modules.commonsetup=function(AAUI){/* NOT NEEDED */};
